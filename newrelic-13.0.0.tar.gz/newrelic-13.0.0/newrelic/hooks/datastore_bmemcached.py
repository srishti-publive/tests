# Copyright 2010 New Relic, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from newrelic.api.datastore_trace import wrap_datastore_trace

_memcache_client_methods = (
    "get",
    "gets",
    "get_multi",
    "set",
    "cas",
    "set_multi",
    "add",
    "replace",
    "delete",
    "delete_multi",
    "incr",
    "decr",
    "flush_all",
    "stats",
)


def capture_host(self, *args, **kwargs):
    if hasattr(self, "servers"):
        for s in self.servers:
            if hasattr(s, "host"):
                return s.host


def capture_port(self, *args, **kwargs):
    if hasattr(self, "servers"):
        for s in self.servers:
            if hasattr(s, "port"):
                return s.port


def instrument_bmemcached_client(module):
    for name in _memcache_client_methods:
        if hasattr(module.Client, name):
            wrap_datastore_trace(
                module,
                f"Client.{name}",
                product="Memcached",
                target=None,
                operation=name,
                host=capture_host,
                port_path_or_id=capture_port,
            )
