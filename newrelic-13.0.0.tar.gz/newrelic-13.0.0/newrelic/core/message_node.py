# Copyright 2010 New Relic, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from collections import namedtuple

import newrelic.core.trace_node
from newrelic.core.metric import TimeMetric
from newrelic.core.node_mixin import GenericNodeMixin

_MessageNode = namedtuple(
    "_MessageNode",
    [
        "library",
        "operation",
        "children",
        "start_time",
        "end_time",
        "duration",
        "exclusive",
        "destination_name",
        "destination_type",
        "params",
        "guid",
        "agent_attributes",
        "user_attributes",
        "span_link_events",
        "span_event_events",
    ],
)


class MessageNode(_MessageNode, GenericNodeMixin):
    @property
    def name(self):
        name = f"MessageBroker/{self.library}/{self.destination_type}/{self.operation}/Named/{self.destination_name}"
        return name

    def time_metrics(self, stats, root, parent):
        """Return a generator yielding the timed metrics for this
        messagebroker node as well as all the child nodes.

        """
        name = self.name

        # Unscoped metric

        yield TimeMetric(name=name, scope="", duration=self.duration, exclusive=self.exclusive)

        # Scoped metric

        yield TimeMetric(name=name, scope=root.path, duration=self.duration, exclusive=self.exclusive)

        # Now for the children, if the trace is not terminal.

        for child in self.children:
            for metric in child.time_metrics(stats, root, self):  # noqa: UP028
                yield metric

    def trace_node(self, stats, root, connections):
        name = root.string_table.cache(self.name)

        start_time = newrelic.core.trace_node.node_start_time(root, self)
        end_time = newrelic.core.trace_node.node_end_time(root, self)

        children = []

        root.trace_node_count += 1

        params = self.get_trace_segment_params(root.settings, params=self.params)

        return newrelic.core.trace_node.TraceNode(
            start_time=start_time, end_time=end_time, name=name, params=params, children=children, label=None
        )

    def span_event(self, settings, base_attrs=None, parent_guid=None, attr_class=dict):
        return base_attrs, attr_class, self.span_link_events, self.span_event_events
